
Proyecto base React Native - RJ video IA

Requisitos:
- Node.js
- Expo CLI (npm install -g expo-cli)
- Android Studio o dispositivo Android

Pasos para correr la app:
1. npm install
2. npx expo start
3. Escanea el QR desde la Expo Go App o ejecuta en emulador

Para generar APK (requiere ejectuar `eas build` o usar Android Studio):
https://docs.expo.dev/classic/building-standalone-apps/

Nota: Esta versión es un prototipo funcional mínimo viable (MVP) que permite:
- Cargar un video desde el teléfono
- Simular IA
- Preparar para exportación

Diseño visual: fondo negro, letras blancas
